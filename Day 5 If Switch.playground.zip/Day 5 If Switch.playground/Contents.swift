let score = 88
if score > 80 {
    print("Great Music")
}

let speed = 88
let percentage = 85
let age = 18

if speed >= 88 {
    print("Where we're going we don't need roads.")
}

if percentage < 85 {
    print("Sorry, you failed the test.")
}

if age >= 18 {
    print("You're eligible to vote")
}

let ourName = "Dave Lister"
let friendName = "Arnold Rimmer"

if ourName > friendName {
    print("It's \(friendName) vs \(ourName)")
}


// Make an array of 3 numbers
var numbers = [1, 2, 3]

// Add a 4th
numbers.append(4)

// If we have over 3 items
if numbers.count > 3 {
    // Remove the oldest number
    numbers.remove(at: 0)
}

// Display the result
print(numbers)


let country = "Canada"

if country == "Canada" {
    print("G'day!")
}

let name = "Taylor Swift"

if name != "Anonymous" {
    print("Welcome, \(name)")
}

let names = "muna"

if names != "madan" {
    print("Welcome,\(names)")
}

// Create the username variable
var username = ""

// If `username` contains an empty string
if username == "" {
    // Make it equal to "Anonymous"
    username = "Anonymous"
}

// Now print a welcome message
print("Welcome, \(username)!")

if username.count == 0 {
    username = "Anonymous"
}

if username.isEmpty == true {
    username = "Anonymous"
}

if username.isEmpty {
    username = "Anonymous"
}

print(username)

// Check Multiple Conditions

let ages = 16

if ages >= 18 {
    print("You can vote in next election")
} else {
    print("Sorry, you're too young to vote")
}

//if a {
//    print("Code to run if a is true")
//} else if b {
//    print("code to run is a is false but b is true")
//} else {
//    print("code to run if a is none")
//}

var temp = 25
if temp >= 30 {
    print("Its too hot in here")
} else if temp <= 30 {
    print("The temp is moderate")
} else {
    print("The temp might be moderate")
}

if temp > 20 && temp < 30 {
    print("It's a nice day")
}

let userAge = 18
let hasParentalConsent = true

if age >= 18 || hasParentalConsent {
    print("You're eligible to buy the game")
}

// Complex Example

enum TransportOption {
    case airplane, helicopter, bicycle, car, escotter
}

let transport = TransportOption.escotter

if transport == .airplane || transport == .helicopter {
    print("Lets fly")
} else if transport == .bicycle {
    print("I hope theres a bike path")
} else if transport == .car {
    print("Hope there's not much traffic")
} else {
    print("have a great time with your escotter")
}

// Switch
enum weather {
    case sun, rain, wind, snow, unknown
}

let forecast = weather.rain

switch forecast {
case .rain:
    print("Pick an umbrella")
case .wind:
    print("Take care it's windy")
case .sun:
    print("It must be a nice day")
case .snow:
    print("School is cancelled")
case .unknown:
    print("Our forecase generator is broken")
default:
    print("Who are you ?")
}

let day = 5
print("My true love gave to me..")

switch day {
case 5:
    print("5 Golden Rings")
    fallthrough
case 4:
    print("4 Golden Rings")
    fallthrough
case 3:
    print("3 Golden Rings")
    fallthrough
default:
    print("Default")
    
}






