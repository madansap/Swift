/*
 Complex Data Types
    Arrays - empty to million
 */

var beatles = [ "John", "madan", "Muna", "Mandira"]
var numbers = [ 4,5,6,7,8,9]
var temperatures = [47.0, 98.98]


// Index
print (beatles[0])
print(beatles[1])

// Append
beatles.append("Madan2")
print(beatles)

 var scores = Array<Int>()
scores.append(100)
scores.append(60)
scores.append(50)
print(scores)

var score = [String]()
score.append("Hero")
score.append("Heroine")
print(score)

// .Count
// .Remove
// .Contains("")
// .Sorted

// Dictionaries

let customer = [
    "Name" : "Madan Sapkota",
    "Degree" : "BscIT",
    "Address" : "Kathmandu"
]
print(customer)


var customer1 = [ String: Int]()
customer1 ["Money"] = 100
customer1 ["Degree"] = 100
customer1 ["Silence"] = 0

// Sets for fast data lookup
// Set doesnot care order

let people = Set(["madan", "shiva", "mandira", "muna"])
print(people)

let actors = Set([
    "Madan",
    "Sapkota",
    "Tech"
])
print(actors)

// Adding Item - you cant append so insert
var actor = Set<String>()
actor.insert("Madan Sapkota")
actor.insert("Muna Sapkota")
actor.insert("Mandira Sapkota")


/*
 
 Why not just arrays ?
 - No Duplicates allowed.
 - Stores data in an optimized manner.
 - Fast lookup even in huge data.
 
 */

/*
 Create and use enums
 
 */

var 
selected = "Monday"
selected = "Tuesday"
selected = "January"
selected = "Friday"

enum Weekday {
    case Monday
    case Tuesday
    case Wednesday
    case Thursday
    case Friday
}

var day = Weekday.Monday
day = Weekday.Tuesday
day = Weekday.Friday
print(day)

// Can also be used with commas instead of using cases.
day = .Monday
day = .Tuesday

// Type Annotations

let surname: String = "Sapkota"
var scor: Double = 0

let playerName: String = " Madan"
let luckyNumber: Int = 4
let pi: Double = 3.141
let isAuthenticated: Bool = true

var albums: [String] = ["red", "fearless"]
albums.append("madan")
print(albums[2])

var user: [String : String] = ["id": "madansap"]
print(user)

// Empty Array
var teams: [String] = [String]()
var citi =  [String]()

// Enums Type Annotations

enum UIStyle{
    case light, dark, system
    
}
var style = UIStyle.light
style = .dark











