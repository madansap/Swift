let tempCelsius = 37.0
var tempFahrenheit = (tempCelsius * 9 / 5) + 32

print(tempCelsius)
print(tempFahrenheit)

print("The current temp in celcius is \(tempCelsius) and the temp is fahrenheit os \(tempFahrenheit)")

