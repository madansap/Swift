var movies = [" Idiots", "Inception", "Her", "Charlie"]
movies.append("String Theory")
print("The total number of movies in an Array are \(movies.count)")
print("The total number of unique movies in an Array are \(movies.count)")

var actor = Set<String>()
actor.insert("Madan Sapkota")
actor.insert("Muna Sapkota")
actor.insert("Mandira Sapkota")
actor.insert("Vision OS")

print(actor.count)

print("The total number of actors in a set are \(actor.count). Also the values cannot be repeated data has been stored in the set.")


