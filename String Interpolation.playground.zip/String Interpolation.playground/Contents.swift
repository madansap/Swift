import UIKit
var greeting = "Hello, playground"
// Boolean

let goodDogs = true
print(goodDogs)

let isMultiple = 120.isMultiple(of: 6)

// String Concatination - Great for small things but not effective

let people = "Haters"
let action = "hate"
let lyric = people + "gonna" + action

// String Interpolation - \() inside the string - More effective
let name = "taylor"
let age = 26
let message = "Hello, my name is \(name) and I am \(age) years old."

let number = 11
let missionMessage = "Apollo  \(number) landed on moon"

/*
 Summary Simple Data
 - let and var
 - Integers Int (is multipleof)
 - Double for decimal numbers
 - Store truth with Bool
 - String Interpolation \()
 */

