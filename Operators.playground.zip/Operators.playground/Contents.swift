import UIKit

/*
 Module 2 - Operators
 An operator is a special symbol or phrase that you use to check, change or combine values
 */

// Assignment Operator

var firstName = "Madan"
var x = 1
var y = 4
var lastName = "Sapkota"


// Binary Operator

x + y
x - y
x * y
x / y
x % y //Remainder


// Compound Assignment Operators

var likes = 1
likes += 1 // Liking a Post
likes -= 1 // Unliking a post


// Comparision Operators

x == y // Checks if x is equal to y - Gives us boolean variables.
x != y // Checks if x is not equal than y
x > y
x < y
x >= y
x >= y





