import UIKit

/*
 Constants and variables allows us to store data of particular types in properties.
 They associate a name with a particular value of particular type.
 Variables can be muted or changed, constants cannot.
 */

// MARK - Strings
var greeting = "Hello, playground"
var firstName = "Madan"
var lastName = "Sapkota"
print(firstName + lastName)

// MARK - Numbers

var x = 2
var y = 3
print(x+y)

x = 4
y = 6
print(x+y)

// MARK - Bolean

var havingFun = true
print(havingFun)

// Constants - Requires less memory (Not Mutable)
let a = 1
let b = 2
let birthday = 1999
let girlFriend = true
print(girlFriend)







